import React from 'react'

const Users = () => {
  return (
    <div></div>
  )
}

export default Users