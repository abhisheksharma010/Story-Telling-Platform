import React from 'react';
import './StoryCard.css'

const StoryCard = () => {
    return (
        <div>StoryCard</div>
    )
}

export default StoryCard